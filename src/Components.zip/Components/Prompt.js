class Prompt extends React.Component {
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }

}